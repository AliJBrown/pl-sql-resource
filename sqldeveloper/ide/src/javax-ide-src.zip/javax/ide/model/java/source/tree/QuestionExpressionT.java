/*
 * @(#)QuestionExpressionT.java
 */

package javax.ide.model.java.source.tree;

/**
 * An expression with the ?: operator, formally known as the
 * "conditional operator". <p/>
 *
 * @author Andy Yu
 * */
public interface QuestionExpressionT
  extends OperatorExpressionT
{
}
