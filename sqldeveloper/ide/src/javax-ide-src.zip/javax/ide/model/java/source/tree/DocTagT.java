/*
 * @(#)DocTagT.java
 */

package javax.ide.model.java.source.tree;

/**
 * @deprecated
 */
abstract class DocTagT
{
}
