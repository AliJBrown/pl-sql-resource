/*
 * @(#)ParameterD.java
 */

package javax.ide.model.java.declaration;

/**
 * Represents a parameter.
 *
 * @author Andy Yu
 */
public interface ParameterD
  extends Declaration, HasNameD, HasTypeD, HasAnnotationsD
{
  /**
   * True if this is a variable-arity parameter.
   *
   * @return True if this is a variable-arity parameter.
   */
  public boolean isVarArgs();
}
