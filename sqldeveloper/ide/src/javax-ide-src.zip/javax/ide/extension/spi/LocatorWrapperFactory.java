/* $Header: jdev/src/javaxide/src/javax/ide/extension/spi/LocatorWrapperFactory.java /main/1 2011/06/09 13:42:57 svassile Exp $ */

/* Copyright (c) 2011, Oracle and/or its affiliates. All rights reserved. */

/*
   DESCRIPTION
    <short description of component this file declares/defines>

   PRIVATE CLASSES
    <list of private classes defined - with one-line descriptions>

   NOTES
    <other useful comments, qualifications, etc.>

   MODIFIED    (MM/DD/YY)
    svassile    06/02/11 - Creation
 */

/**
 *  @version $Header: LocatorWrapperFactory.java 02-jun-2011.13:55:56 svassile Exp $
 *  @author  svassile
 *  @since   release specific (what release of product did this appear in)
 */

package javax.ide.extension.spi;

import javax.xml.stream.Location;

public interface LocatorWrapperFactory
{
  LocatorWrapper wrapLocation(LocationAdapter locator);
}
